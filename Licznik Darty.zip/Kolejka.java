package org.example;

public class Kolejka {

    Sektor r1,r2,r3;

    public Kolejka(Sektor r1, Sektor r2, Sektor r3) {
        this.r1 = r1;
        this.r2 = r2;
        this.r3 = r3;
    }

    @Override
    public String toString() {
        return "Kolejka{" +
                "r1=" + r1 +
                ", r2=" + r2 +
                ", r3=" + r3 +
                '}';
    }

    int suma() {
        return r1.wartosc*r1.mnoznik + r2.wartosc*r2.mnoznik + r3.wartosc*r3.mnoznik;
    }
}
