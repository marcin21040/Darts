package org.example;

import java.util.ArrayList;
import java.util.List;

public class App
{
    List<Sektor> sektory = new ArrayList<>();
    List<Sektor> podwojne = new ArrayList<>();

    List<Kolejka> kolejki = new ArrayList<>();

    void generujSektory() {
        sektory.add(new Sektor(0,1));
        for (int i = 1; i <= 20; i++) {
            sektory.add(new Sektor(i,1));
            sektory.add(new Sektor(i,2));
            sektory.add(new Sektor(i,3));
            podwojne.add(new Sektor(i,2));
        }
        sektory.add(new Sektor(25,1));
        sektory.add(new Sektor(25,2));
        podwojne.add(new Sektor(25,2));
    }

    void generujKolejki() {
        for (int i = 0; i < sektory.size(); i++) {
            for (int j = 0; j < sektory.size(); j++) {
                for (int k = 0; k < podwojne.size(); k++) {
                    kolejki.add(new Kolejka(sektory.get(i),sektory.get(j),podwojne.get(k)));
                }
            }
        }
    }

    List<Kolejka> mozliwosci(int liczba) {
        List<Kolejka> result = new ArrayList<>();
        for (int i = 0; i < kolejki.size(); i++) {
            if (kolejki.get(i).suma() == liczba) {
                result.add(kolejki.get(i));
            }
        }
        return result;
    }

    List<Integer> nieDaSie() {
        List<Integer> result = new ArrayList<>();
        for (int i = 2; i <= 180; i++) {
            if (mozliwosci(i).size() == 0) {
                result.add(i);
            }
        }
        return result;
    }

    public static void main( String[] args )
    {
        App app = new App();
        app.generujSektory();
        app.generujKolejki();
        System.out.println(app.mozliwosci(167));
        System.out.println(app.nieDaSie());
    }
}
