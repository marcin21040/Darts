package org.example;

public class Sektor {

    int wartosc, mnoznik;

    public Sektor(int wartosc, int mnoznik) {
        this.wartosc = wartosc;
        this.mnoznik = mnoznik;
    }

    @Override
    public String toString() {
        return wartosc + "(x" + mnoznik + ")";
    }
}
